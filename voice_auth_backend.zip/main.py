from fastapi import FastAPI, File, UploadFile, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel
from typing import List
import shutil
import uuid
import os
import numpy as np
import jwt
import datetime

app = FastAPI()

# CORS settings
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# JWT Secret (use a secure key in production)
SECRET_KEY = "your-secret-key"
ALGORITHM = "HS256"

# Simulated database
users_db = {}
voiceprints_dir = "voiceprints"
os.makedirs(voiceprints_dir, exist_ok=True)

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

class User(BaseModel):
    username: str
    voiceprint: str

@app.post("/register/")
async def register_user(user: User):
    if user.username in users_db:
        raise HTTPException(status_code=400, detail="User already exists")
    users_db[user.username] = {"voiceprint": user.voiceprint}
    return {"message": "User registered successfully"}

@app.post("/enroll/")
async def enroll(username: str, file: UploadFile = File(...)):
    file_path = os.path.join(voiceprints_dir, f"{username}.npy")
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    return {"message": "Voice enrolled successfully"}

@app.post("/authenticate/")
async def authenticate(username: str, file: UploadFile = File(...)):
    enrolled_path = os.path.join(voiceprints_dir, f"{username}.npy")
    if not os.path.exists(enrolled_path):
        raise HTTPException(status_code=404, detail="Enrollment not found")

    test_path = os.path.join(voiceprints_dir, f"temp_{uuid.uuid4().hex}.npy")
    with open(test_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    enrolled = np.load(enrolled_path)
    test = np.load(test_path)
    os.remove(test_path)

    similarity = np.dot(enrolled, test) / (np.linalg.norm(enrolled) * np.linalg.norm(test))
    if similarity > 0.9:
        token = jwt.encode({
            "sub": username,
            "exp": datetime.datetime.utcnow() + datetime.timedelta(hours=1)
        }, SECRET_KEY, algorithm=ALGORITHM)
        return {"access_token": token, "token_type": "bearer"}
    else:
        raise HTTPException(status_code=401, detail="Voice not recognized")

@app.post("/token")
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    user = users_db.get(form_data.username)
    if not user:
        raise HTTPException(status_code=400, detail="Incorrect username or password")
    token = jwt.encode({
        "sub": form_data.username,
        "exp": datetime.datetime.utcnow() + datetime.timedelta(hours=1)
    }, SECRET_KEY, algorithm=ALGORITHM)
    return {"access_token": token, "token_type": "bearer"}