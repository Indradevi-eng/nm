
from flask import Flask, request, render_template_string
from voice_auth import enroll_user, authenticate_user

app = Flask(__name__)

TEMPLATE = '''
<!DOCTYPE html>
<html>
<head><title>Healthcare Portal</title></head>
<body>
    <h2>Healthcare Voice Login</h2>
    <form method="POST" action="/enroll">
        <input name="username" placeholder="Enter username for enrollment"/>
        <button type="submit">Enroll Voice</button>
    </form>
    <br>
    <form method="POST" action="/login">
        <input name="username" placeholder="Enter username to login"/>
        <button type="submit">Login via Voice</button>
    </form>
    <p>{{ message }}</p>
</body>
</html>
'''

@app.route("/", methods=["GET"])
def index():
    return render_template_string(TEMPLATE, message="")

@app.route("/enroll", methods=["POST"])
def enroll():
    username = request.form["username"]
    enroll_user(username)
    return render_template_string(TEMPLATE, message=f"Enrolled {username} successfully.")

@app.route("/login", methods=["POST"])
def login():
    username = request.form["username"]
    success, message = authenticate_user(username)
    return render_template_string(TEMPLATE, message=message)

if __name__ == "__main__":
    app.run(debug=True)
