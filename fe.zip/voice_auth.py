
import os
import numpy as np
import librosa
import sounddevice as sd
from scipy.spatial.distance import cosine

SAMPLE_RATE = 22050
DURATION = 5  # seconds
ENROLL_DIR = "enrollments"

def record_voice(prompt="Please speak now...", duration=DURATION):
    print(prompt)
    audio = sd.rec(int(duration * SAMPLE_RATE), samplerate=SAMPLE_RATE, channels=1)
    sd.wait()
    return audio.flatten()

def extract_features(audio):
    mfcc = librosa.feature.mfcc(y=audio, sr=SAMPLE_RATE, n_mfcc=13)
    return np.mean(mfcc, axis=1)

def enroll_user(username):
    audio = record_voice(f"Enrolling {username}. Please say your passphrase clearly.")
    features = extract_features(audio)
    os.makedirs(ENROLL_DIR, exist_ok=True)
    np.save(os.path.join(ENROLL_DIR, f"{username}.npy"), features)
    print(f"Voiceprint saved for user: {username}")

def authenticate_user(username):
    try:
        stored_features = np.load(os.path.join(ENROLL_DIR, f"{username}.npy"))
    except FileNotFoundError:
        return False, "User not enrolled."

    audio = record_voice(f"{username}, please say your passphrase to login.")
    new_features = extract_features(audio)

    similarity = 1 - cosine(stored_features, new_features)
    if similarity > 0.85:
        return True, f"Access granted. Similarity: {similarity:.2f}"
    else:
        return False, f"Access denied. Similarity: {similarity:.2f}"
